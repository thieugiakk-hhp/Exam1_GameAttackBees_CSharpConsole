Bài tập 1: Game con ong
Danh sách thành viên:
- Vũ Quang Minh - 1911064897
- Lê Bá Khương - 1911064858
- Trần Lê Thanh Vỹ - 1911061104
- Hoàng Hồng Phong - 1911060514